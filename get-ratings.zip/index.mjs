import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand, GetCommand } from '@aws-sdk/lib-dynamodb';
import { Agent } from "https";

// Create HTTP agent with connection pooling
const httpAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 30000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    scheduling: 'lifo'
});

// Create clients outside the handler for connection reuse
const client = new DynamoDBClient({
    maxAttempts: 3,
    requestTimeout: 30000,
    httpAgent
});

const dynamodb = DynamoDBDocumentClient.from(client, {
    // Document client configuration for better performance
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false
    },
    unmarshallOptions: {
        wrapNumbers: false
    }
});

export const handler = async (event) => {    
    const sessionId = event.pathParameters?.sessionId;
    const ticketId = event.queryStringParameters?.ticketId;
    
    const corsHeaders = {
        'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGIN,
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Content-Type': 'application/json'
    };
    
    if (!sessionId) {
        return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'Session ID is required' })
        };
    }
    
    if (!ticketId) {
        return {
            statusCode: 401,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Ticket ID is required for ratings access',
                hint: 'Add ?ticketId=YOUR_TICKET_ID to the URL'
            })
        };
    }
    
    try {
        // Parallel execution of ticket validation and ratings retrieval for better performance
        const [ticketResult, ratingsResult] = await Promise.allSettled([
            // Get ticket information
            dynamodb.send(new GetCommand({
                TableName: process.env.SPEAKER_TICKETS_TABLE,
                Key: { ticketId: ticketId },
                ConsistentRead: false // Use eventually consistent reads for better performance
            })),
            
            // Query ratings (we'll validate access after getting ticket, but fetch in parallel for speed)
            dynamodb.send(new QueryCommand({
                TableName: process.env.RATINGS_TABLE,
                KeyConditionExpression: 'sessionId = :sessionId',
                ExpressionAttributeValues: {
                    ':sessionId': sessionId
                },
                ConsistentRead: false // Use eventually consistent reads
            }))
        ]);
        
        // Handle ticket validation
        if (ticketResult.status === 'rejected') {
            console.error('Error validating ticket:', ticketResult.reason);
            return {
                statusCode: 500,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Failed to validate ticket' })
            };
        }
        
        if (!ticketResult.value.Item) {
            return {
                statusCode: 401,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Invalid ticket ID',
                    ticketId: ticketId
                })
            };
        }
        
        const ticket = ticketResult.value.Item;
        
        if (!ticket.isActive) {
            return {
                statusCode: 401,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Ticket is deactivated',
                    ticketHolder: ticket.ticketHolder
                })
            };
        }
        
        // Handle String Set for allowedSessions
        const allowedSessions = ticket.allowedSessions;
        let hasAccess = false;
        let accessLevel = 'speaker';
        
        if (allowedSessions && allowedSessions.has) {
            // Check if it's a Set containing the wildcard
            if (allowedSessions.has('*')) {
                hasAccess = true;
                accessLevel = 'admin';
            }
            // Check if the sessionId is in the Set
            else if (allowedSessions.has(sessionId)) {
                hasAccess = true;
            }
        }
        
        if (!hasAccess) {
            return {
                statusCode: 403,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Access denied for this session',
                    requestedSession: sessionId
                })
            };
        }
        
        // Handle ratings query
        if (ratingsResult.status === 'rejected') {
            console.error('Error fetching ratings:', ratingsResult.reason);
            return {
                statusCode: 500,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Failed to retrieve ratings' })
            };
        }
        
        const ratings = ratingsResult.value.Items || [];
        const totalRatings = ratings.length;
        
        if (totalRatings === 0) {
            return {
                statusCode: 200,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    sessionId,
                    totalRatings: 0,
                    averages: { contentSatisfaction: 0, speakerEffectiveness: 0 },
                    learnedSomethingPercentage: { yes: 0, no: 0 },
                    feedback: [],
                    ticketHolder: ticket.ticketHolder,
                    accessLevel,
                    generatedAt: new Date().toISOString()
                })
            };
        }
        
        // Optimized single-pass calculation for better performance
        let contentSum = 0;
        let speakerSum = 0;
        let learnedYes = 0;
        const feedbackItems = [];
        
        // Process all ratings in a single loop
        for (const rating of ratings) {
            contentSum += rating.contentSatisfaction;
            speakerSum += rating.speakerEffectiveness;
            
            if (rating.learnedSomething === true) {
                learnedYes++;
            }
            
            // Collect feedback items with timestamps for sorting
            if (rating.additionalFeedback && rating.additionalFeedback.trim() !== '') {
                feedbackItems.push({
                    contentRating: rating.contentSatisfaction,
                    speakerRating: rating.speakerEffectiveness,
                    feedback: rating.additionalFeedback,
                    submittedAt: rating.submittedAt,
                    // Add timestamp for sorting (convert to number for faster sorting)
                    sortTimestamp: new Date(rating.submittedAt).getTime()
                });
            }
        }
        
        // Sort feedback by timestamp (most recent first) and take top 10
        const feedback = feedbackItems
            .sort((a, b) => b.sortTimestamp - a.sortTimestamp)
            .slice(0, 10)
            .map(item => ({
                contentRating: item.contentRating,
                speakerRating: item.speakerRating,
                feedback: item.feedback,
                submittedAt: item.submittedAt
            }));
        
        const response = {
            sessionId,
            totalRatings,
            averages: {
                contentSatisfaction: Math.round((contentSum / totalRatings) * 100) / 100,
                speakerEffectiveness: Math.round((speakerSum / totalRatings) * 100) / 100
            },
            learnedSomethingCount: { yes: learnedYes, no: totalRatings - learnedYes },
            learnedSomethingPercentage: { 
                yes: Math.round((learnedYes / totalRatings) * 100),
                no: Math.round(((totalRatings - learnedYes) / totalRatings) * 100)
            },
            feedback,
            ticketHolder: ticket.ticketHolder,
            accessLevel,
            generatedAt: new Date().toISOString()
        };
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify(response)
        };
        
    } catch (error) {
        console.error('Error in speaker ratings handler:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Internal server error',
                message: error.message 
            })
        };
    }
};