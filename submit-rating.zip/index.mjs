import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';
import { randomUUID } from 'crypto';
import { Agent } from "https";

// Create HTTP agent with connection pooling
const httpAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 30000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    scheduling: 'lifo'
});

// Create clients outside the handler for connection reuse
const client = new DynamoDBClient({
    maxAttempts: 3,
    requestTimeout: 30000,
    httpAgent
});

const dynamodb = DynamoDBDocumentClient.from(client, {
    // Document client configuration for better performance
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false
    },
    unmarshallOptions: {
        wrapNumbers: false
    }
});

export const handler = async (event) => {    
    const corsHeaders = {
        'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGIN,
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Content-Type': 'application/json'
    };

    let ratingData;
    try {
        ratingData = JSON.parse(event.body || '{}');
    } catch (error) {
        return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'Invalid JSON in request body' })
        };
    }
    
    const sessionId = ratingData.sessionId;
    
    if (!sessionId) {
        return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'Session ID is required in request body' })
        };
    }
    
    // Enhanced validation with better error messages
    const requiredFields = ['contentSatisfaction', 'speakerEffectiveness', 'learnedSomething'];
    const missingFields = requiredFields.filter(field => 
        ratingData[field] === undefined || ratingData[field] === null || ratingData[field] === ''
    );
    
    if (missingFields.length > 0) {
        return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Missing required fields',
                missing: missingFields,
                received: Object.keys(ratingData)
            })
        };
    }
    
    // Validate rating ranges
    const contentSatisfaction = parseInt(ratingData.contentSatisfaction);
    const speakerEffectiveness = parseInt(ratingData.speakerEffectiveness);
    
    if (isNaN(contentSatisfaction) || isNaN(speakerEffectiveness) ||
        contentSatisfaction < 1 || contentSatisfaction > 5 ||
        speakerEffectiveness < 1 || speakerEffectiveness > 5) {
        return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Rating values must be integers between 1 and 5',
                received: {
                    contentSatisfaction: ratingData.contentSatisfaction,
                    speakerEffectiveness: ratingData.speakerEffectiveness
                }
            })
        };
    }
    
    // Validate learnedSomething field
    const validLearnedSomethingValues = ['yes', 'no', true, false];
    if (!validLearnedSomethingValues.includes(ratingData.learnedSomething)) {
        return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'learnedSomething must be "yes", "no", true, or false',
                received: ratingData.learnedSomething
            })
        };
    }
    
    try {
        // Generate unique rating ID with better entropy
        const ratingId = `${Date.now()}#${randomUUID()}`;
        const timestamp = new Date().toISOString();
        
        // Sanitize and validate optional feedback
        const additionalFeedback = ratingData.additionalFeedback ? 
            String(ratingData.additionalFeedback).trim().substring(0, 1000) : ''; // Limit feedback length
        
        const ratingItem = {
            sessionId: sessionId,
            ratingId: ratingId,
            contentSatisfaction: contentSatisfaction,
            speakerEffectiveness: speakerEffectiveness,
            learnedSomething: ratingData.learnedSomething === 'yes' || ratingData.learnedSomething === true,
            additionalFeedback: additionalFeedback,
            eventName: ratingData.eventName ? String(ratingData.eventName).trim() : '',
            sessionTitle: ratingData.sessionTitle ? String(ratingData.sessionTitle).trim() : '',
            speakerName: ratingData.speakerName ? String(ratingData.speakerName).trim() : '',
            submittedAt: timestamp
        };
        
        // Use conditional expression to prevent duplicate submissions (if needed)
        await dynamodb.send(new PutCommand({
            TableName: process.env.RATINGS_TABLE,
            Item: ratingItem
            // Note: Could add ConditionExpression if we want to prevent duplicates based on some criteria
        }));
        
        console.log('Rating submitted successfully:', {
            ratingId,
            sessionId,
            contentSatisfaction,
            speakerEffectiveness,
            learnedSomething: ratingItem.learnedSomething,
            timestamp
        });
        
        return {
            statusCode: 200,
            headers: {
                ...corsHeaders,
                'Access-Control-Allow-Methods': 'POST, OPTIONS' // More specific for successful submission
            },
            body: JSON.stringify({ 
                success: true, 
                ratingId,
                submittedAt: timestamp,
                message: 'Rating submitted successfully'
            })
        };
        
    } catch (error) {
        console.error('Error submitting rating:', {
            error: error.message,
            sessionId,
            ratingData: {
                contentSatisfaction: ratingData.contentSatisfaction,
                speakerEffectiveness: ratingData.speakerEffectiveness,
                learnedSomething: ratingData.learnedSomething
            }
        });
        
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to submit rating',
                message: 'Please try again later'
            })
        };
    }
};